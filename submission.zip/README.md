# Security Enhancements in Python Applications

A self-contained Python security benchmark demonstrating vulnerability identification, threat mitigation, and code hardening.

## Mini Line Architecture Description
- `vulnerable_app.py`: Baseline showcasing SQLi, plaintext passwords, command injection, path traversal, and raw traceback leaks.
- `secure_app.py`: Hardened implementation with parameterized queries, salted PBKDF2 hashing, regex validation, and path confinement.
- `test_security.py`: Automated suite simulating malicious injection payloads, rainbow table resistance, and traversal bypasses.
- `SECURITY_REPORT.md`: Audit report with CVSS scores, real-world attack scenarios, and remediation snippets.
- `submission.zip`: Self-contained submission archive containing all deliverables.

## Quickstart

```bash
# Run security test suite
python -m unittest test_security.py

# Run hardened application
python secure_app.py

# Run vulnerable baseline
python vulnerable_app.py
```
